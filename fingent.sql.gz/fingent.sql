-- Adminer 4.7.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `mark_list`;
CREATE TABLE `mark_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term` tinyint(4) NOT NULL COMMENT ' 1 => 1st Term, 2 => 2nd Term, 3 => 3rd Term',
  `maths` decimal(4,0) NOT NULL,
  `science` decimal(4,0) NOT NULL,
  `history` decimal(4,0) NOT NULL,
  `students_id` bigint(20) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mark_list_students_id_foreign` (`students_id`),
  CONSTRAINT `mark_list_students_id_foreign` FOREIGN KEY (`students_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `mark_list` (`id`, `term`, `maths`, `science`, `history`, `students_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1,	2,	50,	50,	40,	1,	'2022-08-10 18:39:46',	'2022-08-10 12:27:52',	'2022-08-10 18:39:46'),
(2,	2,	80,	60,	90,	7,	NULL,	'2022-08-10 18:53:52',	'2022-08-10 18:54:08');

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_resets_table',	1),
(3,	'2019_08_19_000000_create_failed_jobs_table',	1),
(4,	'2022_08_10_031423_create_teachers_table',	1),
(5,	'2022_08_10_061839_create_students_table',	2),
(6,	'2022_08_10_142150_create_mark_list_table',	3);

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_birth` date DEFAULT NULL,
  `gender` tinyint(4) NOT NULL COMMENT ' 1 => Male , 2 => Female, 3 => Other',
  `teachers_id` bigint(20) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `students_teachers_id_foreign` (`teachers_id`),
  CONSTRAINT `students_teachers_id_foreign` FOREIGN KEY (`teachers_id`) REFERENCES `teachers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `students` (`id`, `name`, `date_birth`, `gender`, `teachers_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1,	'Rajesh PV',	'2000-06-01',	1,	4,	NULL,	'2022-08-10 03:42:13',	'2022-08-10 05:42:13'),
(2,	'ABC',	'2001-02-10',	2,	3,	NULL,	'2022-08-10 05:42:59',	'2022-08-10 05:45:23'),
(3,	'Shareena',	'1998-04-02',	2,	5,	'2022-08-10 07:57:59',	'2022-08-10 05:54:30',	'2022-08-10 07:57:59'),
(4,	'Salim KS',	'1998-09-04',	1,	5,	NULL,	'2022-08-10 05:58:34',	'2022-08-10 05:58:34'),
(5,	'ABC A',	'2002-03-07',	1,	3,	'2022-08-10 18:53:20',	'2022-08-10 05:59:37',	'2022-08-10 18:53:20'),
(6,	'ABC XYC',	'2011-10-08',	2,	5,	'2022-08-10 07:46:19',	'2022-08-10 06:04:04',	'2022-08-10 07:46:19'),
(7,	'Sabareesha T',	'2004-05-04',	2,	5,	NULL,	'2022-08-10 18:52:05',	'2022-08-10 18:53:07');

DROP TABLE IF EXISTS `teachers`;
CREATE TABLE `teachers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `teachers` (`id`, `name`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1,	'Ramesh Nair',	'2022-08-10 00:36:57',	'2022-08-09 22:49:20',	'2022-08-10 00:36:57'),
(2,	'Seema TK',	'2022-08-10 00:36:49',	'2022-08-09 22:50:54',	'2022-08-10 00:36:49'),
(3,	'Arun Aniyappan',	NULL,	'2022-08-09 22:52:32',	'2022-08-10 00:15:33'),
(4,	'Seban Joseph',	NULL,	'2022-08-09 22:55:10',	'2022-08-10 00:14:58'),
(5,	'Sruthi S Menon',	NULL,	'2022-08-10 00:37:10',	'2022-08-10 07:29:16'),
(6,	'XYXDEF',	'2022-08-10 18:43:04',	'2022-08-10 18:42:21',	'2022-08-10 18:43:04');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- 2022-08-11 00:49:26
